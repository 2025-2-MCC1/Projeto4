using UnityEngine;

public class Testedarotaçãodesala : MonoBehaviour
{
    public GameObject Parede1;
    public GameObject Parede2;
    public GameObject Parede3;
    public GameObject Parede4;

    public Transform roomTransform;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        transform.rotation = Quaternion.Euler(0, 90, 0);
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.RightArrow))
        {
            transform.Rotate(0, -90f, 0);
        }
        else if (Input.GetKeyDown(KeyCode.LeftArrow))
        {
            transform.Rotate(0, 90f, 0);
        }
        float angle = Mathf.Round(roomTransform.eulerAngles.y) % 360;

        switch ((int)angle)
        {
            case 0:
                {
                    Parede1.SetActive(true);
                    Parede2.SetActive(false);
                    Parede3.SetActive(false);
                    Parede4.SetActive(true);
                    break;
                }

            case 90:
                {
                    Parede1.SetActive(true);
                    Parede2.SetActive(false);
                    Parede3.SetActive(true);
                    Parede4.SetActive(false);
                    break;
                }

            case 180:
                {
                    Parede1.SetActive(false);
                    Parede2.SetActive(true);
                    Parede3.SetActive(true);
                    Parede4.SetActive(false);
                    break;
                }

            case 270:
                {
                    Parede1.SetActive(false);
                    Parede2.SetActive(true);
                    Parede3.SetActive(false);
                    Parede4.SetActive(true);
                    break;
                }
        }
    }
}
