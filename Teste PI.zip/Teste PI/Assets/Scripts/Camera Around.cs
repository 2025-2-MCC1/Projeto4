using UnityEngine;

public class CameraAround : MonoBehaviour
{
    public Transform alvo;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.RightArrow))
        {
            transform.RotateAround(alvo.position, Vector3.up, 90f);
        }
        else if (Input.GetKeyDown(KeyCode.LeftArrow))
        {
            transform.RotateAround(alvo.position, Vector3.up, -90f);

        }
    }
}
